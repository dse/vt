#include "Copyright"

#define scrwidth   80
#define scrheight  24
#define groups     2
#define charwidth  15
#define charheight 12
#define cells      96

/* Data structure for display image */
unsigned char display [scrwidth][scrheight][groups][charwidth],
	scrmap[scrwidth][scrheight], dispindx[cells], dispindy[cells];
