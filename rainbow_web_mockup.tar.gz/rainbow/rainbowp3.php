<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head> 
	 <title> Rexair Rainbow Vacuum Cleaners </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content=" the Rexair Rainbow sets the standard with the world's finest Home Cleaning technology ">
<meta name="keywords" content=" rainbow, vacuums, cleaning systems ">
<!-- <link href="stylep3.css" rel="stylesheet" type="text/css"> -->
<style type="text/css">
<?php include "./stylep3.css"; ?>
</style>
<script language="JavaScript" type="text/javascript" src="./layoutscript.js"></script>
<?php if($do!="email") { ?>
<script language="JavaScript" type="text/javascript" src="./emailvalidator.js"></script>
<script language="JavaScript" type="text/JavaScript">
<!--
function clearText(thefield){
	if (thefield.defaultValue==thefield.value) {
		thefield.value = "";
	}
}
function verify(form) {
	empty = 0;
	if (document.emailmsg.fromname.value == "") {
		empty = 1;
	}
	if (document.emailmsg.fromadr.value == "") {
		empty = 1;
	}
	if (document.emailmsg.subject.value == "") {
		empty = 1;
	}
	if (document.emailmsg.msg.value == document.emailmsg.msg.defaultValue || document.emailmsg.msg.value == "") {
		empty = 1;
	}
	if(!emailCheck(document.emailmsg.fromadr.value)) { return false; }

	if (empty) {
		alert('You did not fill in at least one of the fields. Please go back and make sure that all of them are filled in correctly.');
		return false;
	} else {
		return true;
	}
}
//-->
</script>
<?php } ?>
</head> 
<body> 
<div id="logo"><img src="banner.jpg" alt="Rainbow Appliance"></div><br clear="all">

<div id="left" width="144">
<div class="box">
<a href="#logo">Home</a>
<a href="#left">About Us</a>
<a href="#content">Contact Us</a>
<a href="">&nbsp;</a>
</div>
</div>

<div width="16" class="sbi" id="rlsideimg2">&nbsp;</div>

<div id="content">
<?php

function valid_email($email) {
 // Returns true if email address has a valid form.
 $pattern = "^[-_.[:alnum:]]+@((([[:alnum:]]|[[:alnum:]][[:alnum:]-]*[[:alnum:]])\.)+(ad|ae|aero|af|ag|ai|al|am|an|ao|aq|ar|arpa|as|at|au|aw|az|ba|bb|bd|be|bf|bg|bh|bi|biz|bj|bm|bn|bo|br|bs|bt|bv|bw|by|bz|ca|cc|cd|cf|cg|ch|ci|ck|cl|cm|cn|co|com|coop|cr|cs|cu|cv|cx|cy|cz|de|dj|dk|dm|do|dz|ec|edu|ee|eg|eh|er|es|et|eu|fi|fj|fk|fm|fo|fr|ga|gb|gd|ge|gf|gh|gi|gl|gm|gn|gov|gp|gq|gr|gs|gt|gu|gw|gy|hk|hm|hn|hr|ht|hu|id|ie|il|in|info|int|io|iq|ir|is|it|jm|jo|jp|ke|kg|kh|ki|km|kn|kp|kr|kw|ky|kz|la|lb|lc|li|lk|lr|ls|lt|lu|lv|ly|ma|mc|md|mg|mh|mil|mk|ml|mm|mn|mo|mp|mq|mr|ms|mt|mu|museum|mv|mw|mx|my|mz|na|name|nc|ne|net|nf|ng|ni|nl|no|np|nr|nt|nu|nz|om|org|pa|pe|pf|pg|ph|pk|pl|pm|pn|pr|pro|ps|pt|pw|py|qa|re|ro|ru|rw|sa|sb|sc|sd|se|sg|sh|si|sj|sk|sl|sm|sn|so|sr|st|su|sv|sy|sz|tc|td|tf|tg|th|tj|tk|tm|tn|to|tp|tr|tt|tv|tw|tz|ua|ug|uk|um|us|uy|uz|va|vc|ve|vg|vi|vn|vu|wf|ws|ye|yt|yu|za|zm|zw)|(([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5])\.){3}([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5]))$";
 if(eregi($pattern, $email)) return true;
 else  return false;
}

if($do=="email")
{

echo "http post vars fromname is \"";
echo $HTTP_POST_VARS['fromname'];
echo "\"<br>\n";
echo "http post vars fromadr is \"";
echo $HTTP_POST_VARS['fromadr'];
echo "\"<br>\n";
echo "http post vars subject is \"";
echo $HTTP_POST_VARS['subject'];
echo "\"<br>\n";
echo "http post vars msg is \"";
echo $HTTP_POST_VARS['msg'];
echo "\"<br><br>\n";

$to="david@localhost";
if(!isset($subject)||($subject=="")) $subject="testing";
if(!isset($msg)) $msg="did it work?";
if(!isset($fromname)||($fromname=="")) $fromname="bob testing";
if(!isset($fromadr)||($fromadr=="")) $fromadr="sue@localhost";

$subject=stripslashes($subject);
$msg=stripslashes($msg);
$fromname=stripslashes($fromname);

echo ('to address: "'.$to.'"<br>
from name: "'.$fromname.'"<br>
from address: "'.$fromadr.'"<br>
subject: "'.preg_replace('#[\n\r]+#s', '', $subject).'"<br>
message: "'.preg_replace("#(?<!\r)\n#s","\n",$msg).'"<br>
');

/*echo (trim($to).'<br>'.
trim(preg_replace('#[\n\r]+#s', '', $subject)).'<br>'.
preg_replace("#(?<!\r)\n#s","\n",trim($msg)).'<br>'.
trim($extra_headers).'<br>');*/

/* @mail(trim($to), trim(preg_replace('#[\n\r]+#s', '', $subject)), preg_replace("#(?<!\r)\n#s", "\n", trim($msg)), trim($extra_headers)); */

// Stop the form being used from an external URL
// Get the referring URL
$referer = $HTTP_REFERER."?do=email";
// Get the URL of this page
$this_url = "http://".$HTTP_HOST.$REQUEST_URI;

    // If the referring URL and the URL of this page don't match then
    // display a message and don't send the email.
    if ($referer != $this_url) {
        echo "You do not have permission to use this script from another URL.";
        exit;
    }

    // The URLs matched so send the email

	if(valid_email($fromadr))
	{
/*$result = imap_mail($to, $subject, $msg, "From: $fromname <$fromadr>");

echo "<br><br>$result<br>\n";*/

echo "<br>Thank you, $fromname, for your interest in our products and services, we will get back to you shortly.<br>\n";

	/*if (!$result)
	{
	echo ('Failed sending email :: '. __LINE__ . __FILE__);
	}*/
	}
	else { echo "<br><br>The e-mail address you entered is not valid, please try again.<br>\n"; }

echo "<br><div style=\"text-align:center;\"><a href=\"$HTTP_REFERER\">Go back</a></div>\n";
}
else {
$fromname="tester bill";
$fromadr="rebecca@localhost";
$subject="aftermath testing";
?>
<form action="?do=email" method="post" name="emailmsg" onsubmit="return verify(this.form)">
<table width="100%" border="1">
<tr><td>Your Name: </td><td><input type="text" size="40" name="fromname" value="<?php echo $fromname; ?>" class="txtfld"></td></tr>
<tr><td>Your E-mail address: </td><td><input type="text" size="40" name="fromadr" value="<?php echo $fromadr; ?>" class="txtfld"></td></tr>
<tr><td>Subject: </td><td><input type="text" size="40" name="subject" value="<?php echo $subject; ?>" class="txtfld"></td></tr>
<tr><td colspan="3" align="center"><textarea rows="18" cols="60" name="msg" onfocus="clearText(this)">Type your message here.</textarea></td></tr>
<tr><td colspan="3" align="center"><input type="submit" value="Send E-mail" class="btn">&nbsp;<input type="reset" value="Reset" class="btn">
<!-- <input type="image" name="submit" src="sendmail.gif" alt="Send E-mail" border="0">&nbsp;<input type="image" name="reset" src="reset.gif" alt="Reset" border="0"> --></td></tr>
</table>
</form>
<?php } ?>
</div>
<!--<td width="16">
<table class="sbi"><tr><td id="llsideimg1">&nbsp;</td></tr><tr><td id="llsideimg2">&nbsp;</td></tr><tr><td id="llsideimg3">&nbsp;</td></tr></table></td>-->
</body>
</html>
