<?php

/**
 * Change the email address to your own.
 *
 * $empty_fields_message and $thankyou_message can be changed
 * if you wish.
 */

// Change to your own email address
$your_email = "david@localhost"; /*"you@example.com";*/

// This is what is displayed in the email subject line
// Change it if you want
$subject = "Message via your contact form";

// This is displayed if all the fields are not filled in
$empty_fields_message = "<p>Please go back and complete all the fields in the form.</p>";

// This is displayed when the email has been sent
$thankyou_message = "<p>Thankyou. Your message has been sent.</p>";

// You do not need to edit below this line

$name = stripslashes($_POST['txtName']);
$email = stripslashes($_POST['txtEmail']);
$message = stripslashes($_POST['txtMessage']);

if (!isset($_POST['txtName'])) {

?>

<form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">

    <p><label for="txtName">Name:</label><br />
    <input type="text" title="Enter your name" name="txtName" /></p>

    <p><label for="txtEmail">Email:</label><br />
    <input type="text" title="Enter your email address" name="txtEmail" /></p>

    <p><label for="txtMessage">Your message:</label><br />
    <textarea title="Enter your message" name="txtMessage"></textarea></p>

    <p><label title="Send your message">
    <input type="submit" value="Send" /></label></p>

</form>

<?php

}

elseif (empty($name) || empty($email) || empty($message)) {

    echo $empty_fields_message;

}

else {

    // Stop the form being used from an external URL
    // Get the referring URL
    $referer = $_SERVER['HTTP_REFERER'];
    // Get the URL of this page
    $this_url = "http://".$_SERVER['HTTP_HOST'].$_SERVER["REQUEST_URI"];
    // If the referring URL and the URL of this page don't match then
    // display a message and don't send the email.
    if ($referer != $this_url) {
        echo "You do not have permission to use this script from another URL.";
        exit;
    }

    // The URLs matched so send the email
    mail($your_email, $subject, $message, "From: $name <$email>");

    // Display the thankyou message
    echo $thankyou_message;
    
}

?>