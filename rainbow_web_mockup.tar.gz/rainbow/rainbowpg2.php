<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head> 
	 <title> Rainbow Layout Test Page </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="stylep3.css" rel="stylesheet" type="text/css">

</head> 
<body> 
<div id="logo"><img src="banner4.jpg" alt="Rainbow"></div><br clear="all">


<div id="left" width="144">
<div class="box">
<a href="#logo">Home</a>
<a href="#left">About Us</a>
<a href="#content">Contact Us</a>
<a href="">&nbsp;</a>
</div>
</div>

<div width="16" class="sbi" border="0" id="rlsideimg2">&nbsp;</div>

<div id="content">

<p>Lorem ipsum dolor sit amet,
 consectetuer adipiscing elit.
 Curabitur erat erat, malesuada et,
 volutpat vitae, viverra ac,
 ipsum. In congue, magna et condimentum suscipit,
 enim sem vestibulum purus, non congue mi risus eget massa.
 Nam dapibus pede sed <a href="felis.htm">felis</a>. Vivamus nec metus at mi ultricies pellentesque.
 Sed nonummy justo consectetuer libero. Phasellus suscipit consectetuer libero.
 Nulla facilisi. Morbi urna eros, commodo eu, accumsan nec, aliquam ac, erat.
 Morbi eu velit non sem placerat iaculis. Mauris lacinia ullamcorper tortor.
 Nullam sodales ligula vel libero. Aenean pede.
 Donec lorem lectus, ultricies a, viverra non, dapibus ac, magna.
 Curabitur ut ligula.</p>
 <p>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
 Ut mi mauris, interdum ut, laoreet eu, elementum vel, wisi.
 Aenean posuere velit vitae lectus.</p>

<p>Lorem ipsum dolor sit amet,
 consectetuer adipiscing elit.
 Curabitur erat erat, malesuada et,
 volutpat vitae, viverra ac,
 ipsum. In congue, magna et condimentum suscipit,
 enim sem vestibulum purus, non congue mi risus eget massa.
 Nam dapibus pede sed <a href="felis.htm">felis</a>. Vivamus nec metus at mi ultricies pellentesque.
 Sed nonummy justo consectetuer libero. Phasellus suscipit consectetuer libero.
 Nulla facilisi. Morbi urna eros, commodo eu, accumsan nec, aliquam ac, erat.
 Morbi eu velit non sem placerat iaculis. Mauris lacinia ullamcorper tortor.
 Nullam sodales ligula vel libero. Aenean pede.
 Donec lorem lectus, ultricies a, viverra non, dapibus ac, magna.
 Curabitur ut ligula.</p>
 <p>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
 Ut mi mauris, interdum ut, laoreet eu, elementum vel, wisi.
 Aenean posuere velit vitae lectus.</p>

<p>Lorem ipsum dolor sit amet,
 consectetuer adipiscing elit.
 Curabitur erat erat, malesuada et,
 volutpat vitae, viverra ac,
 ipsum. In congue, magna et condimentum suscipit,
 enim sem vestibulum purus, non congue mi risus eget massa.
 Nam dapibus pede sed <a href="felis.htm">felis</a>. Vivamus nec metus at mi ultricies pellentesque.
 Sed nonummy justo consectetuer libero. Phasellus suscipit consectetuer libero.
 Nulla facilisi. Morbi urna eros, commodo eu, accumsan nec, aliquam ac, erat.
 Morbi eu velit non sem placerat iaculis. Mauris lacinia ullamcorper tortor.
 Nullam sodales ligula vel libero. Aenean pede.
 Donec lorem lectus, ultricies a, viverra non, dapibus ac, magna.
 Curabitur ut ligula.</p>
 <p>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
 Ut mi mauris, interdum ut, laoreet eu, elementum vel, wisi.
 Aenean posuere velit vitae lectus.</p>

</div>

</body>
</html>
