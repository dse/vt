<!--
function MM_reloadPage(init) {  //Updated by PVII. Reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) history.go(0);
}
MM_reloadPage(true);

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

// layer name, left, top, width, height (these are numbers or the word 'auto')
// then, left margin, right margin, top margin, bottom margin
function P7_fluidLayers(el,lp,tp,wp,hp,lm,rm,tm,bm) { //v0.5 beta -experimental testing script by PVII
	var x,g,d,sw,sh,xx,yy,ww,hh,pa='',t="','",u=",";
	if((g=MM_findObj(el))==null){return;}
	if((parseInt(navigator.appVersion)>4 || navigator.userAgent.indexOf("MSIE")>-1)&& !window.opera){pa="px";}
	var tS="P7_fluidLayers('"+el+t+lp+t+tp+t+wp+t+hp+"',"+lm+u+rm+u+tm+u+bm+")";
	if(window.innerWidth) {sw= window.innerWidth;sh = window.innerHeight;
	}else if(document.body) {sw=document.body.clientWidth;sh=document.body.clientHeight;
    if(document.body.offsetWidth == sw && document.documentElement && document.documentElement.clientWidth) {
	 sw=document.documentElement.clientWidth;}
    if(document.body.offsetHeight == sh && document.documentElement && document.documentElement.clientHeight) {
     sh=document.documentElement.clientHeight;}}
	if(!g.p7fluid) {g.p7fluid=true;g.p7fluidw=0;g.p7fluidh=0;}
	if(sw==g.p7fluidw && sh==g.p7fluidh) {setTimeout(tS,20);return;}
	d=(document.layers)?g:g.style;
	if(wp=='auto') {if(lp=='auto'){ww=sw-lm-rm;}else{ww=sw-lp-rm;}}else{ww=wp;}
	if(hp=='auto') {if(tp=='auto'){hh=sh-tm-bm;}else{hh=sh-tp-bm;}}else{hh=hp;}
	if(lp=='auto') {if(wp=='auto'){xx=lm;}else{xx=sw-wp-rm;}}else{xx=lp;}
	if(tp=='auto') {if(hp=='auto'){yy=tm;}else{yy=sh-tp-bm;}}else{yy=tp;}
	d.left=xx+pa;d.top=yy+pa;
	if(document.layers){g.clip.height=hh;g.clip.width=ww;
	}else if(window.opera){g.style.pixelHeight=hh;g.style.pixelWidth=ww;
	}else{d.width=ww+pa;d.height=hh+pa;}
	g.p7fluidw=sw;g.p7fluidh=sh;
	setTimeout(tS,20);
}

function img_height(el) { 
	var x,g,d,sw,sh,xx,yy,ww,hh,pa='';
	if((g=MM_findObj(el))==null){return;}
	if((parseInt(navigator.appVersion)>4 || navigator.userAgent.indexOf("MSIE")>-1)&& !window.opera){pa="px";}
	if(document.body) {sw=document.body.clientWidth;sh=document.body.clientHeight;
    if(document.body.offsetWidth == sw && document.documentElement && document.documentElement.offsetWidth) {
	 sw=document.documentElement.clientWidth;}
    if(document.body.offsetHeight == sh && document.documentElement && document.documentElement.clientHeight) {
     sh=document.documentElement.clientHeight;}}
	else if(window.innerWidth) {sw= window.innerWidth;sh = window.innerHeight;}
	d=(document.layers)?g:g.style;

hh=sh-140-50-40-40;

	if(document.layers){g.clip.height=hh;
	}else if(window.opera){g.style.pixelHeight=hh;
	}else{d.height=hh+pa;}
	g.p7fluidw=sw;g.p7fluidh=sh;
}

function img_pos(el) { 
	var x,g,d,sw,sh,xx,yy,ww,hh,pa='';
	if((g=MM_findObj(el))==null){return;}
	if((parseInt(navigator.appVersion)>4 || navigator.userAgent.indexOf("MSIE")>-1)&& !window.opera){pa="px";}
	if(document.body) {sw=document.body.clientWidth;sh=document.body.clientHeight;
    if(document.body.offsetWidth == sw && document.documentElement && document.documentElement.clientWidth) {
	 sw=document.documentElement.clientWidth;}
    if(document.body.offsetHeight == sh && document.documentElement && document.documentElement.clientHeight) {
     sh=document.documentElement.clientHeight;}}
	else if(window.innerWidth) {sw= window.innerWidth;sh = window.innerHeight;}
	d=(document.layers)?g:g.style;

yy=sh-50-40;

	if(document.layers){g.clip.top=yy;
	}else if(window.opera){d.style.pixelTop=yy;
	}else{d.offsetTop=yy+pa;}
	g.p7fluidw=sw;g.p7fluidh=sh;
}
//-->