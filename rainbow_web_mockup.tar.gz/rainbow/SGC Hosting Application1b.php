<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head> 
<title>SGC Hosting Application</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php if($do!="email") { ?>
<script language="JavaScript" type="text/javascript" src="./emailvalidator.js"></script>
<script language="JavaScript" type="text/JavaScript">
<!--
function verify(form) {
	empty = 0;
	if (document.ha_form.username.value == "") {
		empty = 1;
	}
	if (document.ha_form.password.value == "") {
		empty = 1;
	}
	if (document.ha_form.password2.value == "") {
		empty = 1;
	}
	if (document.ha_form.subdomain.value == "") {
		empty = 1;
	}
	if (document.ha_form.useremail.value == "") {
		empty = 1;
	}
	if (document.ha_form.useremail2.value == "") {
		empty = 1;
	}
	if (document.ha_form.content.value == "") {
		empty = 1;
	}

	if(!emailCheck(document.ha_form.useremail.value)) { return false; }

	if (empty) {
		alert('You did not fill in at least one of the required fields. Please go back and make sure that all of them are filled in correctly.');
		return false;
	} else if (document.ha_form.useremail.value != document.ha_form.useremail2.value) {
		alert('Please make sure that you entered your e-mail address correctly.');
		return false;
	} else if (document.ha_form.password.value != document.ha_form.password2.value) {
		alert('Please make sure that the passwords you entered match.');
		return false;
	} else {
		return true;
	}
}
//-->
</script>
<?php } ?>
</head>
<body>  

<?php 

function valid_email($email) {
 // Returns true if email address has a valid form.
 $pattern = "^[-_.[:alnum:]]+@((([[:alnum:]]|[[:alnum:]][[:alnum:]-]*[[:alnum:]])\.)+(ad|ae|aero|af|ag|ai|al|am|an|ao|aq|ar|arpa|as|at|au|aw|az|ba|bb|bd|be|bf|bg|bh|bi|biz|bj|bm|bn|bo|br|bs|bt|bv|bw|by|bz|ca|cc|cd|cf|cg|ch|ci|ck|cl|cm|cn|co|com|coop|cr|cs|cu|cv|cx|cy|cz|de|dj|dk|dm|do|dz|ec|edu|ee|eg|eh|er|es|et|eu|fi|fj|fk|fm|fo|fr|ga|gb|gd|ge|gf|gh|gi|gl|gm|gn|gov|gp|gq|gr|gs|gt|gu|gw|gy|hk|hm|hn|hr|ht|hu|id|ie|il|in|info|int|io|iq|ir|is|it|jm|jo|jp|ke|kg|kh|ki|km|kn|kp|kr|kw|ky|kz|la|lb|lc|li|lk|lr|ls|lt|lu|lv|ly|ma|mc|md|mg|mh|mil|mk|ml|mm|mn|mo|mp|mq|mr|ms|mt|mu|museum|mv|mw|mx|my|mz|na|name|nc|ne|net|nf|ng|ni|nl|no|np|nr|nt|nu|nz|om|org|pa|pe|pf|pg|ph|pk|pl|pm|pn|pr|pro|ps|pt|pw|py|qa|re|ro|ru|rw|sa|sb|sc|sd|se|sg|sh|si|sj|sk|sl|sm|sn|so|sr|st|su|sv|sy|sz|tc|td|tf|tg|th|tj|tk|tm|tn|to|tp|tr|tt|tv|tw|tz|ua|ug|uk|um|us|uy|uz|va|vc|ve|vg|vi|vn|vu|wf|ws|ye|yt|yu|za|zm|zw)|(([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5])\.){3}([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5]))$";
 if(eregi($pattern, $email)) return true;
 else  return false;
}

if($do=="email")
{
$errors = 0;
$none = 0;

if ($password!=$password2) {
echo "<strong>The passwords do not match!<br></strong>";
$errors = 1;
  }
if ($useremail!=$useremail2) {
echo "<strong>The entered e-mail addresses do not match!<br></strong>";
$errors = 1;
  }
if ($errors==$none)
  {

// Stop the form being used from an external URL
// Get the referring URL
$referer = $HTTP_REFERER."?do=email";
// Get the URL of this page
$this_url = "http://".$HTTP_HOST.$REQUEST_URI;

    // If the referring URL and the URL of this page don't match then
    // display a message and don't send the email.
    if ($referer != $this_url) {
        echo "You do not have permission to use this script from another URL.";
        exit;
    }

    // The URLs matched so send the email

	if(valid_email($useremail))
	{

$autosubject = "Hosting Application Recieved";
$automessage = "
<html>
<body>
DO NOT REPLY TO THIS MESSAGE.<p>

 This is just an automated email saying your application has been recieved and is awaiting reviewal by a SGC Admin.<br>
You don't have to do anything, just sit back and wait for us to tell you your accepted or not.
<br>Thanks for interest in SGC Hosting.<P>

 ~SGC Hosting Services
</body>
</html>
";



$autoheaders  = "MIME-Version: 1.0\r\n";
$autoheaders .= "Content-type: text/html; charset=iso-8859-1\r\n";
$autoheaders .= "To: $name\r\n";
$autoheaders .= "From: SGC Hosting\r\n";
$autoheaders .= "Sender: SGC Hosting\r\n";

/* mail($useremail, $autosubject, $automessage, $autoheaders); */
echo ($useremail.$autosubject.$automessage.$autoheaders);


$appto = "hosting@sgcentral.net";
$appsubject = "Hosting Application";
$appmessage = "
<html>
<body>
Username: $username<br>
Password: $password<br>
Subdomain Requested: $subdomain<br>
Real Name: $name<br>
Age: $age<br>
E-mail: $useremail<br>
Content: $content<br>
Previous/Current Website: $website<br>
Comments/Other Info: $comments<br>
</body>
</html>
";

$appheaders  = "MIME-Version: 1.0\r\n";
$appheaders .= "Content-type: text/html; charset=iso-8859-1\r\n";
$appheaders .= "To: SGC Hosting\r\n";
$appheaders .= "From: $username\r\n";
$appheaders .= "Sender: $useremail\r\n";

/* mail($appto, $appsubject, $appmessage, $appheaders); */
echo ($appto.$appsubject.$appmessage.$appheaders);

$date = date("F j, Y");
$time = date("g:i a");

echo "<p>Your application was sent on " . $date . " at " . $time . " CST.\n";

	}
	else { echo "<br><br>The e-mail address you entered is not valid, please try again.<br>\n"; echo "<p>Click <a href=\"$HTTP_REFERER\">here</a> to go back.\n"; die; }

echo "<p>Click <a href=\"http://www.sgcentral.net\" title=\"SGC\">here</a> to return to SGC.\n";
  }
}
else { ?>
All <strong>bold and asteriked (*)</strong> fields are required information.

<form action="?do=email" method="POST" name="ha_form" onsubmit="return verify(this.form)">

<strong>* Username</strong>: <br><input type="text" name="username"><p>

<strong>* Password</strong>: <br><input type="password" name="password"><p>

<strong>* Confirm Password</strong>: <br><input type="password" name="password2"><p>

<strong>* Subdomain</strong>: <br><input type="text" name="subdomain">.sgcentral.net<P>

Real Name: <br><input type="text" name="name"><p>

Age: <br><input type="text" name="age"><p>

<strong>* E-mail:</strong> <br><input type="text" name="useremail"><p>

<strong>* Confirm E-mail:</strong> <br><input type="text" name="useremail2"><p>

<strong>* Website Content:</strong> (Be brief) <br><input type="text" name="content"><p>

Previous/Current website (if any): <br><input type="text" name="website" value="http://"><p>

Comments/Other Info: <br><input type="text" name="comments">

<input type="submit" value="Submit">
</form>
<?php } ?>

</body>
</html>
