Redistribution and use of the files TTSSH.EXE, TTXSSH.DLL and
LIBEAY32.DLL are permitted provided that the following conditions are
met:

-- The redistributed files are not modified.
-- Redistributions must contain this file, readme.txt, possibly under
another name.
-- The conditions of the contributors must be met. In particular, if
LIBEAY32.DLL is included, then LIBEAY.TXT must be included and its
conditions followed.

For up-to-date information on TTSSH, please consult the Web page at
http://www.zip.com.au/~roca/ttssh.html
This page includes information on obtaining the source code, which
grants you additional rights, such as the right to modify TTSSH and
redistribute your modifications under certain conditions.

Thanks,
Robert O'Callahan
roc+tt@cs.cmu.edu
