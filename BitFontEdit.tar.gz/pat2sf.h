#define VERSION Version 3.1, Mar. 1997		/* Version of BitFontEdit     */
#define CELL_WIDTH_MAX	   8	/* Used to allocate array size.		      */
#define CELL_HEIGHT_MAX   16	/* Ditto.				      */
#define CHARS_PER_BAND_MAX 8	/* Ditto.				      */
#define MAX_LINES 530		/* Size of foffset[line_no] vector. 	      */
#define RETURN   0		/* flags for usage() & ListLangs() in encode.c*/
#define EXIT     1		/* ditto				      */
#define ERR_EXIT 2		/* ditto.  print err msg & exit		      */
#define BOOL int

